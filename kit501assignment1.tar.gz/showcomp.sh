#!/bin/bash
# Purpose of this script is that user can compress files with diffrent method.
# And compare with original file size.
# Author : Ravikumar Savani
# Date of last modified : 17 May 2024

# Here will clear screen
tput clear

# Check that users selected file is exist or not
if [ ! -f "$1" ]; then
	echo "Selected file $1 is does not exist, please selected exist one."
	exit
fi

# Check users has select one file at time
if [ $# -ne 1 ]; then
	echo "Please provide one file at time."
	exit
fi

# Check users selected file is readable ot not.
if [ ! -r "$1" ]; then
	echo "Selected file $1 is not readable, please selected readable one."
	exit
fi

# check users selected file size is zero or not
if [ ! -s "$1" ]; then
	echo "Selected file $1 size is null, please selected file which have size more then zero."
	exit
fi

# create a function for give same space when make output like table.
fit() {
	SPACING="               "
	text=$1
	echo "${text}${SPACING:1:${#SPACING}-${#text}}"
}

# To store original file size in variable
ogsize=$(ls -l "$1" | cut -f 5 -d " ")

# create a function to compress users selected file with bzip2 method, and in the end decompress the file
bzipcom() {
	file="$1"

	# to give extention bz2 to selected file
	comfile="$file.bz2"

	# to compressing file with using bz2 method
	bzip2 "$file"

	# to calculate size after compress file
	comsize1=$(ls -l "$comfile" | cut -f 5 -d " ")

	# to calculate the ratio of compression
	comratio1=$(echo "scale=4; $comsize1 / $ogsize" | bc)

	# to decompress selected file
	bunzip2 "$1.bz2"
}

# create a function to compress users selected file with xz method, and in the end decompress the file
xzcom() {
	file="$1"

        # to give extention xz to selected file
        comfile="$file.xz"

	# to compressing file with using xz method
	xz "$file"

        # to calculate size after compress file
        comsize2=$(ls -l "$comfile" | cut -f 5 -d " ")

        # to calculate the ratio of compression
        comratio2=$(echo "scale=4; $comsize2 / $ogsize" | bc)

        # to decompress selected file
        unxz "$1.xz"
}

# create a function to compress users selected file with tar method, and in the end decompress the file
tararchive() {
	file="$1"

        # to give extention tar to selected file
        archivefile="$file.tar"

	# to archive the selected file with tar method
	tar -cvf "$archivefile" "$file" >/dev/null

        # to calculate size after archived file
        archivesize=$(ls -l "$archivefile" | cut -f 5 -d " ")

        # to calculate the ratio of archive
        comratio3=$(echo "scale=4; $archivesize / $ogsize" | bc)

        # to unarchive selected file and send previous to null
        tar xvf "$archivefile" -C "$(dirname "$file")" >/dev/null

	# to delete the tar file
	rm "$archivefile"
}

# create a function to compress users selected file with gzip method, and in the end decompress the file
gzipcom() {
	file="$1"

        # to give extention gz to selected file
        comfile="$file.gz"

	# to compress file with gzip method
	gzip "$file"

        # to calculate size after compress file
        comsize4=$(ls -l "$comfile" | cut -f 5 -d " ")

        # to calculate the ratio of compression
        comratio4=$(echo "scale=4; $comsize4 / $ogsize" | bc)

        # to decompress selected file
        gunzip "$1.gz"
}

# create a function to compress users selected file with zip method, and in the end decompress the file
zipcom() {
	file="$1"

        # to give extention gz to selected file
        comfile="$file.zip"

        # to compress file with zip method
        zip "$comfile" "$file" >/dev/null

        # to calculate size after compress file
        comsize5=$(ls -l "$comfile" | cut -f 5 -d " ")

        # to calculate the ratio of compression
        comratio5=$(echo "scale=4; $comsize5 / $ogsize" | bc)

        # to decompress selected file
        unzip -o "$comfile" >/dev/null

	# Delete zip file
	rm "$comfile"
}

# make default value y so users can enter into while loop
answer=y

# create a while loop so users can contunsly perform the multiple methods and perform multiple case
# in this loop it will check that users select y for continue, and if other selection then it will be exit.


while [ "$answer" = y ]; do
	echo ""
	# Create a output in form of menu so users can selected case
	echo "Please select an option from the following menu:"
	echo -e " 1) Compress $1 with bzip2"
	echo -e " 2) Compress $1 with xz"
	echo -e " 3) Archive $1 with tar"
	echo -e " 4) Compress $1 with gzip"
	echo -e " 5) Compress $1 with zip"
	echo 	" 6) Use all Compression commands and display cummary"
	echo 	" q) quit"
	echo 	""

	echo -e "Enter choice: \c"
	read choice
	
	# create a case for perform from user selected number 
	case $choice in
		1)
			echo -e "Compressing $1 using bzip2:"
			echo -e "Original size		: $ogsize"
			bzipcom "$1"
			echo -e "Compressed size  	: $comsize1"
			echo -e "Compressed ratio       : $comratio1"
			;;
		2)
                        echo -e	"Compressing $1 using xz:"
                        echo -e	"Original size          : $ogsize"
                        xzcom "$1"
                        echo -e	"Compressed size        : $comsize2"
                        echo -e	"Compressed ratio	: $comratio2"
                        ;;
		3)
                        echo -e	"Archive $1 using tar:"
                        echo -e	"Original size          : $ogsize"
                        tararchive "$1"
                        echo -e	"Compressed size        : $archivesize"
                        echo -e	"Compressed ratio	: $comratio3"
                        ;;
		4)
                        echo -e	"Compressing $1 using gzip:"
                        echo -e	"Original size          : $ogsize"
                        gzipcom "$1"
                        echo -e	"Compressed size        : $comsize4"
                        echo -e	"Compressed ratio	: $comratio4"
                        ;;
		5)
                        echo -e	"Compressing $1 using zip:"
                        echo -e	"Original size          : $ogsize"
                        zipcom "$1"
                        echo -e	"Compressed size        : $comsize5"
                        echo -e	"Compressed ratio	: $comratio5"
                        ;;
		6)
			echo "*****************************************************************"
			echo -e "File: $1"
			echo "*****************************************************************"
			echo -e "`fit Command` | `fit orig\ size` | `fit compr\ size` | `fit Compr\ Ratio`"
			echo "*****************************************************************"

			# Perform to compress with all commands and also compre with original size.
			
			bzipcom "$1"
			echo -e "`fit bzip2` | `fit $ogsize` | `fit $comsize1` | `fit $comratio1`"
			
			# Create variable to save best one value of compression
			bestcom="bzip2"
			bestcomsize="$comsize1"
			bestratio="$comratio1"

			xzcom "$1"

			echo -e "`fit xz` | `fit $ogsize` | `fit $comsize2` | `fit $comratio2`"
			if [ $comsize2 -lt $bestcomsize ]; then
				bestcom="xz"
				bestcomsize="$comsize2"
				bestratio="$comratio2"
			fi

			tararchive "$1"

			echo -e "`fit tar` | `fit $ogsize` | `fit $archivesize` | `fit $comratio3`"
			if [ $archivesize -lt $bestcomsize ]; then
				bestcom="tar"
				bestcomsize="$archivesize"
				bestratio="$comratio3"
			fi
			
			gzipcom "$1"

                        echo -e	"`fit gzip` | `fit $ogsize` | `fit $comsize4` | `fit $comratio4`"
                        if [ $comsize4 -lt $bestcomsize ]; then
                                bestcom="gzip"
                                bestcomsize="$comsize4"
                                bestratio="$comratio4"
                        fi
			
			zipcom "$1"

                        echo -e "`fit zip` | `fit $ogsize` | `fit $comsize5` | `fit $comratio5`"
                        if [ $comsize5 -lt $bestcomsize ]; then 
                                bestcom="zip"
                                bestcomsize="$comsize5"
                                bestratio="$comratio5"
                        fi

			# here will print after check best compression ratio
			echo "*****************************************************************"
			echo -e "$bestcom had the best compression ratio ($bestratio)"
			;;
			
			[qQ])
				{ echo "Exiting the script."; exit 0; }
				;;

			*)
				echo "Invalid option. Please try again."
				;;
		esac

		echo -e "Run Again? [y/n]: \c"
		read answer
done
